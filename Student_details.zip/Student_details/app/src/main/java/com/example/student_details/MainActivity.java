package com.example.student_details;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    EditText username, password, address, age;
    RadioGroup genderGroup;
    Spinner stateSpinner;
    Button submit;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        address = findViewById(R.id.address);
        age = findViewById(R.id.age);

        genderGroup = findViewById(R.id.genderGroup);
        stateSpinner = findViewById(R.id.stateSpinner);

        submit = findViewById(R.id.submit);
        result = findViewById(R.id.result);

        String[] states = {"Delhi","Uttar Pradesh","Haryana","Punjab","Rajasthan"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                states
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        stateSpinner.setAdapter(adapter);

        submit.setOnClickListener(v -> {

            String name = username.getText().toString();
            String pass = password.getText().toString();
            String addr = address.getText().toString();
            String ag = age.getText().toString();

            int selectedId = genderGroup.getCheckedRadioButtonId();
            RadioButton gender = findViewById(selectedId);

            String genderText = gender.getText().toString();
            String state = stateSpinner.getSelectedItem().toString();

            result.setText(
                    "User Name: " + name +
                            "\nPassword: " + pass +
                            "\nAddress: " + addr +
                            "\nGender: " + genderText +
                            "\nAge: " + ag +
                            "\nState: " + state
            );

        });
    }
}