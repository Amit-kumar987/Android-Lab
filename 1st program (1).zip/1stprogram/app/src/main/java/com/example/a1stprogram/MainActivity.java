package com.example.a1stprogram;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.a1stprogram.R;

public class MainActivity extends AppCompatActivity {

    EditText editName;
    Button btnOk;
    TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editName = findViewById(R.id.editName);
        btnOk = findViewById(R.id.btnOk);
        txtResult = findViewById(R.id.txtResult);

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editName.getText().toString();
                txtResult.setText("Hello " + name);
            }
        });
    }
}
